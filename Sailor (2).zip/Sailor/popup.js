document.getElementById("analyzeBtn").addEventListener("click", async () => {
  const url = document.getElementById("urlInput").value;

  try {
    const res = await fetch("http://localhost:5000/analyze", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ url: url })
});


    

    const data = await res.json();

    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: "highlightArticle",
        score: data.score
      });
    });

    document.getElementById("result").innerText =
      `저널: ${data.journal}\n성향 점수: ${data.score}`;
  } catch (error) {
    console.error("요청 중 오류 발생:", error);
    document.getElementById("result").innerText = "서버와 연결할 수 없습니다.";
  }
});

document.getElementById("flowBtn").addEventListener("click", async () => {
  const issue = document.getElementById("issueInput").value;

  try {
    const res = await fetch(`http://localhost:5000/run?issue=${encodeURIComponent(issue)}`);
    const data = await res.json();

    document.getElementById("flowResult").innerText = data.article || "요약된 결과가 없습니다.";
  } catch (error) {
    console.error("이슈 요약 요청 중 오류:", error);
    document.getElementById("flowResult").innerText = "서버와 연결할 수 없습니다.";
  }
});
