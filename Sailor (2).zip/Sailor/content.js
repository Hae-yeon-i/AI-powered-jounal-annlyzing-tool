chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "highlightArticle") {
    const score = request.score;
    const title = document.querySelector("h1, h2, .article-title");
    if (title) {
      const intensity = Math.min(Math.abs(score) * 50, 255);
      const color = score > 0
        ? `rgb(${intensity},0,0)`   // 좌파: 붉은 계열
        : `rgb(0,0,${intensity})`; // 우파: 푸른 계열
      title.style.color = color;
      title.style.fontWeight = "bold";
    }
  }
});
