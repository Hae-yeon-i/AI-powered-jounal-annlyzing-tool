from datetime import datetime
import os
import openai

openai.api_key = "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"

today = datetime.today().strftime("%Y%m%d")
global_file = f"global_flow_{today}.txt"
domestic_file = f"domestic_flow_{today}.txt"

with open(global_file, "r", encoding="utf-8") as f:
    global_text = f.read()
with open(domestic_file, "r", encoding="utf-8") as f:
    domestic_text = f.read()

combined = global_text + "\n\n" + domestic_text

prompt = (
    "다음은 다양한 언론에서 최근 4개월간 특정 이슈에 대해 보도한 내용입니다. "
    "각 보도의 날짜와 핵심 내용을 기반으로, 전체 흐름이 시간 순서에 따라 자연스럽게 드러나도록 하나의 기사처럼 재구성해주세요.\n\n"
    "- 어느 언론에서 보도했는지는 밝히지 말아 주세요.\n"
    "- 특정 진영이나 정치적 편향이 드러나지 않게 해 주세요.\n"
    "- 기사마다 논조가 다르더라도, 그 차이를 분석적으로 중립적으로 반영해 주세요.\n"
    "- 전체 보도의 전개 흐름이 드러나는 서사 구조로 써 주세요.\n"
    "- 너무 요약하지 말고, 흐름이 보이도록 충분히 상세히 작성해 주세요.\n\n"
    f"아래는 기사 목록입니다:\n\n{combined}"
)

response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": prompt}]
)


with open("article_output.txt", "w", encoding="utf-8") as f:
    f.write(response.choices[0].message.content.strip())
