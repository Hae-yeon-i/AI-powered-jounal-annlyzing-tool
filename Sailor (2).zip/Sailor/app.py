from flask import Flask, request, jsonify
from flask_cors import CORS
import subprocess
import os
import sqlite3
import datetime
import openai
import re

app = Flask(__name__)
CORS(app)

# OpenAI API 키 (당신의 키로 바꿔주세요)
openai.api_key = "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"

# 분석용 DB 경로
DB_PATH = os.path.join(os.getcwd(), "article_read_log.db")

# DB 초기화
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS ReadArticles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url TEXT,
                    journal TEXT,
                    bias_score INTEGER,
                    read_date TEXT
                 )''')
    c.execute('''CREATE TABLE IF NOT EXISTS DailyScores (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT,
                    avg_bias_score REAL
                 )''')
    conn.commit()
    conn.close()

init_db()

# GPT 프롬프트 생성 및 분석
def analyze_article_with_gpt(url):
    prompt = f"""
    보내준 주소의 기사로 들어가서 다음을 분석해줘:
    1) 이 기사를 쓴 저널이 무엇이며
    2) 이 기사의 성향 점수를 분석해줘: 진보에 더 이득이 되는 내용이면 -고, 보수에 더 이득이 되는 내용이면 +. 극단적으로 치우쳐져 있을수록 절댓값을 높이는 방식으로. 범위는 -5~+5으로.
    기사 주소: {url}
    """
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3
        )
        return response['choices'][0]['message']['content']
    except Exception as e:
        return str(e)

def parse_response(text):
    journal = "unknown"
    score = 0
    lines = text.strip().splitlines()
    for line in lines:
        if '저널' in line or 'journal' in line.lower():
            m = re.search(r'([\w.-]+\.[a-z]+)', line)
            if m:
                journal = m.group(1).lower()
        if '점수' in line or 'score' in line.lower():
            n = re.search(r'[-+]?\d+', line)
            if n:
                score = int(n.group())
    return journal, score

def save_article(url, journal, score):
    today = datetime.date.today().isoformat()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('INSERT INTO ReadArticles (url, journal, bias_score, read_date) VALUES (?, ?, ?, ?)',
              (url, journal, score, today))
    conn.commit()
    conn.close()

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.json
    url = data.get('url')
    if not url:
        return jsonify({'error': 'Missing URL'}), 400

    response = analyze_article_with_gpt(url)
    journal, score = parse_response(response)
    save_article(url, journal, score)

    return jsonify({
        'journal': journal,
        'score': score,
        'response': response
    })

# 흐름 요약 기능
@app.route("/run", methods=["GET"])
def run_news_flow():
    issue = request.args.get("issue")
    if not issue:
        return jsonify({"error": "이슈 키워드가 없습니다."}), 400

    # 이슈 키워드를 환경변수로 설정
    os.environ["ISSUE_KEYWORD"] = issue

    # flow_collector.py → collecter.py
    print(f"🔁 [1] 이슈: {issue} → Gemini로 흐름 수집 중...")
    subprocess.run(["python", "collecter.py"])

    # summarizer.py → refiner.py
    print(f"🧠 [2] 수집된 흐름을 GPT로 요약 중...")
    subprocess.run(["python", "refiner.py"])

    try:
        with open("article_output.txt", "r", encoding="utf-8") as f:
            article = f.read()
    except FileNotFoundError:
        return jsonify({"error": "요약된 기사 파일을 찾을 수 없습니다."}), 500

    return jsonify({"issue": issue, "article": article})

if __name__ == '__main__':
    print("🚀 Flask 통합 서버 실행 중...")
app.run(host="0.0.0.0", port=5000, debug=True)
