import os
import google.generativeai as genai
from time import sleep
from datetime import datetime

# API 키 설정
genai.configure(api_key="AIzaSyDuFV0h4eDlDIoyqW7E98WOmtuUBDQ9yNY")

# 문제 키워드 설정 (기본값 제공)
issue = os.getenv("ISSUE_KEYWORD", "2025년에 도널드 트럼프 대통령이 내린 행정명령")  # 기본값 제공

# 파일 이름 설정
today = datetime.today().strftime("%Y%m%d")
global_file = f"global_flow_{today}.txt"
domestic_file = f"domestic_flow_{today}.txt"

# 도메인 리스트 설정 (생략)
international_domains = [ ... ]  
domestic_domains = [ ... ]

# 프롬프트 생성 함수
def make_prompt(domain, issue):
    return (
        f"{domain}에 최근 4달간 '{issue}' 관련해서 낸 보도를 모두 목록으로 정리해줘. "
        f"주요 보도 말고 흐름을 알 수 있게 전체 목록으로 부탁해. 날짜도 가능하면 포함해줘."
    )

# 파일에 저장하는 함수
def save_to_file(domain, response, filename):
    with open(filename, "a", encoding="utf-8") as f:
        f.write(f"{domain}\n\n")
        f.write(response + "\n")
        f.write("-------\n")

# 모델 생성
model = genai.GenerativeModel(model_name="gemini-2.0-flash")

# 모델을 호출하여 데이터 수집하는 함수
def run_collection(domains, filename):
    for i, domain in enumerate(domains, 1):
        print(f"[{i}/{len(domains)}] {domain}")
        prompt = make_prompt(domain, issue)
        try:
            response = model.generate_content(prompt)
            save_to_file(domain, response.text.strip(), filename)
            sleep(1.5)
        except Exception as e:
            print(f"⚠️ 오류: {e}")
            continue


# 데이터 수집 실행
run_collection(international_domains, global_file)
run_collection(domestic_domains, domestic_file)
